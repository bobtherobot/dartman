this.dartman = (function(){

	var store;
	function init(){

		console.log("bob");
		store = storeset.getDataObject();
		console.log("store", store);

	}

	return {
		init : init
	}

}());

console.log("bob");
document.addEventListener("DOMContentLoaded", dartman.init);