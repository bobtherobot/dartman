this.dartman = (function(){

	var store;
	var page = "home";

	var pageList = {
		home : {},
		cricket : {},
		ohone : {}
	};

	var chooseCricketButton;
	var chooseCricketButton;

	function init(){

		store = storeset.getDataObject();

		gotoPage(store.page);

		var elem = document.getElementById("chooseCricket");
		elem.addEventListener("mousedown", chooseCricket);

		var elem = document.getElementById("choose301");
		elem.addEventListener("mousedown", choose301);


	}

	function chooseCricket(){
		gotoPage("cricket");
	}

	function choose301(){
		gotoPage("ohone");
	}

	function gotoPage(Vpage){

		page = Vpage || "home";
		for(var prop in pageList){
			var item = pageList[prop];
			if( ! item.elem ){
				item.elem = document.getElementById("prop");
			}
			item.elem.style.display = "none";
		}

		pageList[page].style.display = "block";

		storeset.set("page", page);

	}

	return {
		init : init
	}

}());


document.addEventListener("DOMContentLoaded", dartman.init);